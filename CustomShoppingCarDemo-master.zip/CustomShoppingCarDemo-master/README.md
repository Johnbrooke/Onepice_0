# CustomShoppingCarDemo
实现美团、饿了么购物车效果，并本地存储相关数据
文章地址：http://blog.csdn.net/csdnfml/article/details/50389357

![image](https://github.com/fengmaolian/CustomShoppingCarDemo/blob/master/CustomShoppingCarDemo/screenshots/20151223140333083.gif)
